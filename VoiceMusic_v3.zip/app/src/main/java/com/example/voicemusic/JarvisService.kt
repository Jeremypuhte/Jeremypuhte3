package com.example.voicemusic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.SearchManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.RoundingMode
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val MODEL = "gemini-flash-latest"
        const val SYSTEM = "Du bist J.A.R.V.I.S., der KI-Butler von Tony Stark aus dem Marvel Cinematic Universe. " +
            "Sprich ruhig, höflich und gewandt, mit trockenem britischem Humor, und sprich den Nutzer mit „Sir“ an. " +
            "Antworte immer auf Deutsch in höchstens zwei kurzen Sätzen, ohne Markdown, ohne Aufzählungen."
        const val ACTION_STOP = "com.example.voicemusic.STOP"
        const val CHANNEL = "jarvis"
        const val NOTIF_ID = 1
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var audio: AudioManager
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var awaitingCommand = false
    private var alive = true

    private val loopRunnable = Runnable {
        if (!alive) return@Runnable
        if (tts?.isSpeaking == true) { scheduleListen(600); return@Runnable }
        startRecognizer()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("vm", MODE_PRIVATE)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification("Zu Ihren Diensten, Sir.")
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicemusic:jarvis").apply { acquire() }

        tts = TextToSpeech(this, this)

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
            scheduleListen(2500)
        } else {
            updateStatus("Keine Spracherkennung gefunden (Google-App installieren).")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ---------- Benachrichtigung ----------
    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Beenden", stop)
            .build()
    }

    private fun updateStatus(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    // ---------- Sprachausgabe ----------
    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            tts?.language = Locale.GERMAN
            tts?.setPitch(0.8f)
            tts?.setSpeechRate(0.95f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { handler.post { if (alive) scheduleListen(400) } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { handler.post { if (alive) scheduleListen(400) } }
            })
            say("Jarvis online. Zu Ihren Diensten, Sir.")
        }
    }

    private fun say(msg: String) {
        updateStatus(msg)
        tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "vm")
        scheduleListen(2000) // Fallback, falls TTS nicht meldet
    }

    // ---------- Zuhören ----------
    private fun scheduleListen(delay: Long) {
        handler.removeCallbacks(loopRunnable)
        handler.postDelayed(loopRunnable, delay)
    }

    private fun startRecognizer() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateStatus("Mikrofon-Erlaubnis fehlt, Sir.")
            stopSelf()
            return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
        }
        recognizer?.cancel()
        recognizer?.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            handleWake(text)
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                updateStatus("Mikrofon-Erlaubnis fehlt, Sir.")
                stopSelf()
                return
            }
            if (awaitingCommand && error != SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                awaitingCommand = false
                updateStatus("Zu Ihren Diensten, Sir.")
            }
            scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 300)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private val wakeRegex = Regex("(hey|hi|hallo|ok)?\\s*(jarvis|dscharvis|charvis|jarwis|dschar wis|jarvas)")

    private fun handleWake(raw: String) {
        val t = raw.lowercase(Locale.GERMAN).trim()
        if (awaitingCommand) {
            awaitingCommand = false
            if (t.isNotBlank()) handle(t) else scheduleListen(300)
            return
        }
        val m = wakeRegex.find(t)
        if (m == null) { scheduleListen(200); return }
        val rest = t.substring(m.range.last + 1).trim().trimStart(',', '.', ' ')
        if (rest.isBlank()) {
            awaitingCommand = true
            say("Ja, Sir?")
        } else {
            handle(rest)
        }
    }

    // ---------- Befehle ----------
    private fun handle(raw: String) {
        val t = raw.lowercase(Locale.GERMAN).trim()
        updateStatus("„$raw“")

        val resume = listOf("weiter", "fortsetzen", "play", "spiel weiter", "mach weiter", "weiterspielen")
        val playPrefix = Regex("^(spiel|spiele|spielt|play|starte|start|abspielen|mach|leg)\\s+(mir\\s+)?(bitte\\s+)?(.+)$")
        val shortCmd = t.split(" ").size <= 6

        val math = tryMath(t)
        when {
            math != null -> say(math)
            t in resume -> { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); say("Sehr wohl, Sir.") }
            playPrefix.matches(t) -> playSearch(playPrefix.find(t)!!.groupValues[4])
            shortCmd && Regex("\\b(pause|pausieren|stopp|stop|anhalten|halt)\\b").containsMatchIn(t) -> {
                mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); say("Pausiert, Sir.")
            }
            shortCmd && (t.contains("nächst") || t.contains("überspring") || t.contains("skip")) -> {
                mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); say("Nächster Titel, Sir.")
            }
            shortCmd && (t.contains("vorherig") || t.contains("zurück")) -> {
                mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); say("Vorheriger Titel, Sir.")
            }
            shortCmd && t.contains("lauter") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                say("Wie Sie wünschen, Sir.")
            }
            shortCmd && t.contains("leiser") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                say("Sehr wohl, Sir.")
            }
            else -> askAi(raw)
        }
    }

    private fun mediaKey(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun playSearch(rawQuery: String) {
        var q = rawQuery.replace(" auf spotify", "").replace(" bei spotify", "").replace(" von ", " ")
        var focus = "vnd.android.cursor.item/*"
        if (q.contains("playlist")) {
            focus = MediaStore.Audio.Playlists.ENTRY_CONTENT_TYPE
            q = q.replace("die playlist", "").replace("playlist", "")
        } else if (q.contains("album")) {
            focus = MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE
            q = q.replace("das album", "").replace("album", "")
        }
        q = q.trim()
        if (q.isEmpty()) { say("Was darf ich spielen, Sir?"); return }

        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage("com.spotify.music")
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, focus)
            putExtra(SearchManager.QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        say("Sehr wohl, Sir.")
        handler.postDelayed({
            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                say("Verzeihung, Sir, Spotify scheint nicht installiert zu sein.")
            }
        }, 1800)
    }

    // ---------- Rechnen (lokal, ohne Internet) ----------
    private val numberWords = mapOf(
        "null" to 0, "eins" to 1, "ein" to 1, "zwei" to 2, "drei" to 3, "vier" to 4, "fünf" to 5,
        "sechs" to 6, "sieben" to 7, "acht" to 8, "neun" to 9, "zehn" to 10, "elf" to 11, "zwölf" to 12
    )

    private fun tryMath(t: String): String? {
        var s = t.replace(",", ".")
        for (p in listOf("was ist", "was ergibt", "wie viel ist", "wieviel ist", "wie viel ergibt",
            "wie viel sind", "was sind", "berechne", "rechne")) s = s.replace(p, " ")
        s = s.replace("geteilt durch", " / ").replace("dividiert durch", " / ")
            .replace("multipliziert mit", " * ").replace("plus", " + ").replace("minus", " - ")
            .replace("mal", " * ").replace("durch", " / ")
        for ((w, n) in numberWords) s = s.replace(Regex("\\b$w\\b"), n.toString())
        val clean = s.replace("?", "").replace(" ", "")
        if (!clean.matches(Regex("[0-9+\\-*/().]+"))) return null
        if (!clean.drop(1).any { it in "+-*/" }) return null
        return try {
            val v = ExprParser(clean).parse()
            if (v.isNaN() || v.isInfinite()) "Durch null kann man nicht teilen, Sir."
            else "Das ergibt " + BigDecimal(v).setScale(4, RoundingMode.HALF_UP)
                .stripTrailingZeros().toPlainString().replace('.', ',') + ", Sir."
        } catch (e: Exception) { null }
    }

    private class ExprParser(val s: String) {
        var p = 0
        fun parse(): Double { val v = expr(); if (p != s.length) throw IllegalArgumentException(); return v }
        fun expr(): Double {
            var v = term()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) { val o = s[p++]; val r = term(); v = if (o == '+') v + r else v - r }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) { val o = s[p++]; val r = factor(); v = if (o == '*') v * r else v / r }
            return v
        }
        fun factor(): Double {
            if (p < s.length && s[p] == '-') { p++; return -factor() }
            if (p < s.length && s[p] == '(') {
                p++; val v = expr()
                if (p >= s.length || s[p] != ')') throw IllegalArgumentException()
                p++; return v
            }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (st == p) throw IllegalArgumentException()
            return s.substring(st, p).toDouble()
        }
    }

    // ---------- Wissensfragen über Gemini (mit Google-Suche) ----------
    private fun askAi(question: String) {
        val key = prefs.getString("key", "").orEmpty()
        if (key.isBlank()) {
            say("Verzeihung, Sir, mir fehlt der API-Schlüssel. Bitte tragen Sie ihn in der App ein.")
            return
        }
        updateStatus("Einen Moment, Sir …")
        Thread {
            val answer = try {
                callGemini(key, question, true)
            } catch (e: Exception) {
                try { callGemini(key, question, false) }
                catch (e2: Exception) { "Verzeihung, Sir, da ist etwas schiefgelaufen. ${e2.message}" }
            }
            handler.post { if (alive) say(answer) }
        }.start()
    }

    private fun callGemini(key: String, q: String, useSearch: Boolean): String {
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", q)))))
            if (useSearch) put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().replace("*", "").trim()
    }
}
