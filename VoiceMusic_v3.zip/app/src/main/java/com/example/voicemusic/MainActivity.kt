package com.example.voicemusic

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyField: EditText
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("vm", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(32, 64, 32, 32)
        }

        status = TextView(this).apply {
            text = "J.A.R.V.I.S.\nZu Ihren Diensten, Sir."
            textSize = 20f
            setTextColor(Color.parseColor("#4FC3F7"))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        root.addView(button("JARVIS STARTEN", "#1565C0", Color.WHITE, 26f) { startJarvis() },
            LinearLayout.LayoutParams(-1, 260))
        root.addView(button("JARVIS BEENDEN", "#3A3A3A", Color.WHITE, 20f) {
            stopService(Intent(this, JarvisService::class.java))
            status.text = "Jarvis ist offline, Sir."
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })

        keyField = EditText(this).apply {
            hint = "Gemini API-Key (für Wissensfragen)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        root.addView(keyField, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        root.addView(button("Key speichern", "#2A2A2A", Color.WHITE, 16f) {
            prefs.edit().putString("key", keyField.text.toString().trim()).apply()
            status.text = "Schlüssel gespeichert, Sir."
        }, LinearLayout.LayoutParams(-1, -2))

        root.addView(button("Spotify im Hintergrund erlauben (Überlagerung)", "#2A2A2A", Color.WHITE, 14f) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        root.addView(button("Akku-Optimierung ausschalten", "#2A2A2A", Color.WHITE, 14f) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(root) }
        setContentView(scroll)
    }

    private fun button(label: String, bg: String, fg: Int, size: Float, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = size
            setBackgroundColor(Color.parseColor(bg))
            setTextColor(fg)
            setOnClickListener { onClick() }
        }

    private fun startJarvis() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) need.add("android.permission.POST_NOTIFICATIONS")
            requestPermissions(need.toTypedArray(), 1)
            status.text = "Bitte erlauben Sie das Mikrofon, Sir."
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java))
        status.text = "Jarvis läuft im Hintergrund, Sir.\nSie können die App schließen."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startJarvis()
        } else {
            status.text = "Ohne Mikrofon kann ich nicht zuhören, Sir."
        }
    }
}
